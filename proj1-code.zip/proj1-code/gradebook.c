#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gradebook.h"

// This is the (somewhat famous) djb2 hash
unsigned hash(const char *str) {
    unsigned hash_val = 5381;
    int i = 0;
    while (str[i] != '\0') {
        hash_val = ((hash_val << 5) + hash_val) + str[i];
        i++;
    }
    return hash_val % NUM_BUCKETS;
}

gradebook_t *create_gradebook(const char *class_name) {
    gradebook_t *new_book = malloc(sizeof(gradebook_t));
    if (new_book == NULL) {
        return NULL;
    }

    strcpy(new_book->class_name, class_name);
    for (int i = 0; i < NUM_BUCKETS; i++) {
        new_book->buckets[i] = NULL;
    }
    new_book->size = 0;

    return new_book;
}

const char *get_gradebook_name(const gradebook_t *book) {
    // TODO Not yet implemented [done]
    return book->class_name;
}

int add_score(gradebook_t *book, const char *name, int score) {
    // TODO Not yet implemented
    // Add a new score to the gradebook (insert into hash table)
// book: A pointer to a gradebook to add the score to
// name: Student's name
// score: Student's score
// Returns: 0 if the score was successfully added/updated
//          or -1 if the score could not be added/updated
    if (score < 0) {
        return -1;
    }

    else {
        int index = hash(name);

        if (book->buckets[index] == NULL) {

            book->buckets[index] = malloc (sizeof(node_t));

            strcpy(book->buckets[index]->name, name);

            book->buckets[index]->score = score;
            book->buckets[index]->next = NULL;
            book->size++;
        }

        else {
            node_t *current = book->buckets[index];
            while (current->next != NULL) {
                if (strcmp(current->name, name) == 0) {
                    current->score = score;
                }
            }
            current->next = malloc(sizeof(node_t));

            strcpy(current->next->name,name);
            
            current->next->score=score;
            current->next->next=NULL;
            book->size++;
            
        }
    }

    return 0;
}

int find_score(const gradebook_t *book, const char *name) {
    // TODO Not yet implemented [done]

    node_t *current = book->buckets[hash(name)];

    if (current != NULL) {
        while (current->next != NULL && strcmp(current->name, name) != 0) {
            current = current->next;
        }

        if (strcmp (current->name, name) == 0) {
            return current->score;
        }
    }

    return -1;

    return -1;
}

void print_gradebook(const gradebook_t *book) {
    // TODO Not yet implemented [done]
    /*Scores for all students in csci_2021:
Sayid: 92
Hurley: 80
Miles: 85
    */ 

   printf("Scores for all students in %s:\n", book->class_name);
   int iteration_num = 0;
   for (int i = 0; i < NUM_BUCKETS && iteration_num < book->size; i++) {
    node_t *current = book->buckets[i];
    while (current != NULL) {
        printf("%s: %d\n", current->name, current->score);
        iteration_num++;
        current = current->next;
    }
   }
}

void free_gradebook(gradebook_t *book) {
    // TODO Not yet implemented [DONE]

    int iteration_num = 0;
    for(int i = 0; i < NUM_BUCKETS && iteration_num < book->size; i++) { 
        node_t *current = book->buckets[i];
        
        if(current != NULL) {
            while(current != NULL) {

                node_t *current2 = current->next;
                free(current);

                iteration_num++;
                current = current2;
            }
        }
    }

    free(book);
}



int write_gradebook_to_text(const gradebook_t *book) {

    char file_name[MAX_NAME_LEN + strlen(".txt")];

    strcpy(file_name, book->class_name);
    strcat(file_name,".txt");

    FILE *f = fopen(file_name,"w");
    if (f == NULL) {
        return -1;
    }

    fprintf(f,"%u\n",book->size);

    for (int i = 0;i<NUM_BUCKETS;i++) {
        node_t *current = book->buckets[i];

        while (current != NULL) {
            fprintf(f,"%s %d\n",current->name, current->score);

            current = current->next;
        }
    }
    
    fclose(f);

    return 0;
}

gradebook_t *read_gradebook_from_text(const char *file_name) {
    // TODO NOT yet implemented [done]


    FILE *f = fopen(file_name,"r");

    if (f == NULL) {
    return NULL;
    }


    char class_name[MAX_NAME_LEN];
    strcpy(class_name, file_name);
    class_name[strlen(class_name)-strlen(".txt")] = '\0';

    gradebook_t *book = create_gradebook(class_name);

    int len = 0;
    fscanf(f,"%d", &len);

    for (int i=0; i<len; i++) {

        char name[MAX_NAME_LEN];
        int score;
        fscanf(f,"%s %d", name, &score);

        add_score(book, name, score);
    }

    fclose(f);

    return book;
}

int write_gradebook_to_binary(const gradebook_t *book) {
    // TODO Not yet implemented [done]
    char file_name[MAX_NAME_LEN + strlen(".bin")];

    strcpy(file_name, book->class_name);
    strcat(file_name,".bin");

    FILE *f = fopen(file_name,"w");
    if (f == NULL) {
        return -1;
    }

    fwrite(&book->size, sizeof(int), 1, f);

    for (int i = 0; i < NUM_BUCKETS; i++) {
        node_t *current = book->buckets[i];

        while (current != NULL) {

            int namelen = strlen(current->name);

            fwrite(&namelen, sizeof(int), 1, f);
            fwrite(current->name, sizeof(char), namelen, f);
            fwrite(&current->score, sizeof(int), 1, f);

            current = current->next;
        }
    }

    fclose(f);

    return 0;
}


gradebook_t *read_gradebook_from_binary(const char *file_name) {
    //[done]
    FILE *f = fopen(file_name,"r");
    if (f==NULL) {
        return NULL;
    }

    int len = 0;
    char class_name[MAX_NAME_LEN];

    strcpy(class_name, file_name);
    class_name[strlen(class_name)-strlen(".txt")] = '\0';
    gradebook_t *book = create_gradebook(class_name);
    fread(&len, sizeof(int), 1, f);

    for(int i = 0; i < len; i++) {
        int score = 0;
        int namelen = 0;

        fread(&namelen, sizeof(int), 1, f);
        char name[namelen];

        fread(name, sizeof(char), namelen, f);
        fread(&score, sizeof(int), 1, f);

        name[namelen] = '\0';


        add_score(book, name, score);

    }

    fclose(f);

    return book;
    
}

