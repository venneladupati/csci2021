// DO NOT MODIFY THIS FILE
int bitAnd(int, int);
int fitsShort(int);
int allEvenBits(int);
int anyOddBit(int);
int isEqual(int, int);
int floatIsEqual(unsigned, unsigned);
int sign(int);
int isAsciiDigit(int);
int floatIsLess(unsigned, unsigned);
int rotateLeft(int, int);
int absVal(int);
unsigned floatScale2(unsigned);

char *func_names[] = {
    "bitAnd",
    "fitsShort",
    "allEvenBits",
    "anyOddBit",
    "isEqual",
    "floatIsEqual",
    "sign",
    "isAsciiDigit",
    "floatIsLess",
    "rotateLeft",
    "absVal",
    "floatScale2"
};
// DO NOT MODIFY THIS FILE
