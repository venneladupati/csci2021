// DO NOT MODIFY THIS FILE
int test_bitAnd(int, int);
int test_fitsShort(int);
int test_allEvenBits(int);
int test_anyOddBit(int);
int test_isEqual(int, int);
int test_floatIsEqual(unsigned, unsigned);
int test_sign(int);
int test_isAsciiDigit(int);
int test_floatIsLess(unsigned, unsigned);
int test_rotateLeft(int, int);
int test_absVal(int);
unsigned test_floatScale2(unsigned);
// DO NOT MODIFY THIS FILE
